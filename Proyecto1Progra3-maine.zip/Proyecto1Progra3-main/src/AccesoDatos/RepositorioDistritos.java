package AccesoDatos;

import Entidades.Persona;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class RepositorioDistritos {

    public void completarUbicacion(Persona persona) {
        BufferedReader br = null;

        try {
            if (persona == null) {
                return;
            }

            if (persona.getCodElectoral() == null || persona.getCodElectoral().trim().equals("")) {
                return;
            }

            File archivo = obtenerArchivoDistritos();

            if (archivo == null) {
                System.out.println("No se encontro el archivo distelec.txt");
                return;
            }

            br = new BufferedReader(new FileReader(archivo));
            String linea;
            String codigoBuscado = persona.getCodElectoral().trim();

            while ((linea = br.readLine()) != null) {
                if (completarSiCoincide(persona, linea, codigoBuscado)) {
                    return;
                }
            }

        } catch (Exception e) {
            System.out.println("Error leyendo distelec.txt: " + e.getMessage());
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (Exception e) {
            }
        }
    }

    private File obtenerArchivoDistritos() {
        String[] rutas = {
            "data/distelec.txt",
            "distelec.txt"
        };

        for (int i = 0; i < rutas.length; i++) {
            File archivo = new File(rutas[i]);
            if (archivo.exists()) {
                return archivo;
            }
        }

        return null;
    }

    private boolean completarSiCoincide(Persona persona, String linea, String codigoBuscado) {
        String[] partes = linea.split(",");

        if (partes.length < 4) {
            return false;
        }

        String codigo = partes[0].trim();

        if (!codigo.equals(codigoBuscado)) {
            return false;
        }

        persona.setProvincia(partes[1].trim());
        persona.setCanton(partes[2].trim());
        persona.setDistrito(partes[3].trim());

        return true;
    }
}