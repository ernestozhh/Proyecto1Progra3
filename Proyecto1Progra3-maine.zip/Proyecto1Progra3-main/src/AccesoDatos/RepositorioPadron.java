package AccesoDatos;

import Entidades.Persona;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class RepositorioPadron {

    public Persona buscarPorCedula(String cedulaBuscada) {
        BufferedReader br = null;

        try {
            File archivo = obtenerArchivoPadron();

            if (archivo == null) {
                System.out.println("No se encontro el archivo PADRON.");
                return null;
            }

            br = new BufferedReader(new FileReader(archivo));
            String linea;

            while ((linea = br.readLine()) != null) {
                Persona persona = convertirLineaAPersona(linea);

                if (persona != null && persona.getCedula().equals(cedulaBuscada)) {
                    RepositorioDistritos repositorioDistritos = new RepositorioDistritos();
                    repositorioDistritos.completarUbicacion(persona);
                    return persona;
                }
            }

        } catch (Exception e) {
            System.out.println("Error leyendo PADRON: " + e.getMessage());
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (Exception e) {
            }
        }

        return null;
    }

    private File obtenerArchivoPadron() {
        String[] rutas = {
            "data/PADRON_COMPLETO.txt",
            "PADRON_COMPLETO.txt",
            "data/PADRON.TXT",
            "PADRON.TXT",
            "data/PADRON",
            "PADRON"
        };

        for (int i = 0; i < rutas.length; i++) {
            File archivo = new File(rutas[i]);
            if (archivo.exists()) {
                return archivo;
            }
        }

        return null;
    }

    private Persona convertirLineaAPersona(String linea) {
        String[] partes = linea.split(",");

        if (partes.length < 8) {
            return null;
        }

        Persona p = new Persona();
        p.setCedula(partes[0].trim());
        p.setCodElectoral(partes[1].trim());
        p.setNombre(partes[5].trim());
        p.setApellido1(partes[6].trim());
        p.setApellido2(partes[7].trim());
        p.setProvincia("");
        p.setCanton("");
        p.setDistrito("");

        return p;
    }
}