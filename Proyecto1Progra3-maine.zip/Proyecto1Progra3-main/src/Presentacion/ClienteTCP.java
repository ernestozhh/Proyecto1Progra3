package Presentacion;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClienteTCP {

    private String host;
    private int puerto;

    public ClienteTCP(String host, int puerto) {
        this.host = host;
        this.puerto = puerto;
    }

    public String enviar(String mensaje) {
        String respuesta = "";

        try (
            Socket socket = new Socket(host, puerto);
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))
        ) {
            out.println(mensaje);

            respuesta = in.readLine();

            if (respuesta == null || respuesta.trim().equals("")) {
                respuesta = "No se recibio respuesta del servidor.";
            }

        } catch (Exception e) {
            respuesta = "Error: " + e.getMessage();
        }

        return respuesta;
    }
}