package Presentacion;

import java.net.ServerSocket;
import java.net.Socket;

public class ServidorTCP {

    private int puerto;

    public ServidorTCP(int puerto) {
        this.puerto = puerto;
    }

    public void iniciar() {
        try (ServerSocket serverSocket = new ServerSocket(puerto)) {

            System.out.println("Servidor TCP escuchando en el puerto " + puerto);
            System.out.println("Protocolo: BUSCAR|JSON|CEDULA o BUSCAR|XML|CEDULA");
            System.out.println("Comando de cierre: BYE");

            while (true) {
                Socket cliente = serverSocket.accept();
                System.out.println("Cliente conectado.");

                ManejadorCliente manejador = new ManejadorCliente(cliente);
                manejador.start();
            }

        } catch (Exception e) {
            System.out.println("Error en el servidor: " + e.getMessage());
        }
    }
}