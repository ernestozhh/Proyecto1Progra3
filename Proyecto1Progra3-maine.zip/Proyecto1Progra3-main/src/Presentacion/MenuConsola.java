/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Loren
 */
package Presentacion;
import java.util.Scanner;

public class MenuConsola {

    private Scanner sc;
    private boolean servidorActivo;

    public MenuConsola() {
        this.sc = new Scanner(System.in);
        this.servidorActivo = false;
    }

    public void iniciar() {
        int opcion;

        do {
            mostrarMenuPrincipal();
            opcion = leerOpcion();

            switch (opcion) {
                case 1:
                    levantarServidor();
                    break;
                case 2:
                    consultarPersona();
                    break;
                case 3:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opcion invalida.");
                    break;
            }

        } while (opcion != 3);
    }

    private void mostrarMenuPrincipal() {
        System.out.println("\n===== Menu =====");
        System.out.println("1. Levantar servidor");
        System.out.println("2. Consultar persona");
        System.out.println("3. Salir");
        System.out.print("Seleccione una opcion: ");
    }

    private int leerOpcion() {
        try {
            return Integer.parseInt(sc.nextLine());
        } catch (Exception e) {
            return 0;
        }
    }

    private void levantarServidor() {
        if (!servidorActivo) {
            Thread servidorThread = new Thread(new Runnable() {
                @Override
                public void run() {
                    ServidorTCP servidor = new ServidorTCP(5000);
                    servidor.iniciar();
                }
            });

            servidorThread.start();
            servidorActivo = true;
            System.out.println("Servidor levantado correctamente.");
        } else {
            System.out.println("El servidor ya esta activo.");
        }
    }

    private void consultarPersona() {
        if (!servidorActivo) {
            System.out.println("Primero debe levantar el servidor.");
            return;
        }

        String formato = leerFormato();

        if (formato.equals("")) {
            System.out.println("Formato invalido.");
            return;
        }

        System.out.print("Ingrese la cedula: ");
        String cedula = sc.nextLine().trim();

        if (cedula.equals("")) {
            System.out.println("La cedula no puede ir vacia.");
            return;
        }

        String comando = "BUSCAR|" + formato + "|" + cedula;

        ClienteTCP cliente = new ClienteTCP("localhost", 5000);
        String respuesta = cliente.enviar(comando);

        System.out.println("\n===== RESPUESTA DEL SERVIDOR =====");
        System.out.println(respuesta);
    }

    private String leerFormato() {
        int opcionFormato;

        System.out.println("\n===== CONSULTA =====");
        System.out.println("1. JSON");
        System.out.println("2. XML");
        System.out.print("Seleccione el formato de respuesta: ");

        try {
            opcionFormato = Integer.parseInt(sc.nextLine());
        } catch (Exception e) {
            opcionFormato = 0;
        }

        switch (opcionFormato) {
            case 1:
                return "JSON";
            case 2:
                return "XML";
            default:
                return "";
        }
    }
}