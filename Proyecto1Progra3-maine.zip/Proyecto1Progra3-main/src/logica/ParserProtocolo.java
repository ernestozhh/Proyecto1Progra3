package logica;

import DTO.FormatoSalida;
import DTO.RespuestaPadron;
import DTO.SolicitudPadron;
import util.Serializador;

public class ParserProtocolo {

    private ServicioPadron servicio;

    public ParserProtocolo() {
        this.servicio = new ServicioPadron();
    }

    public String procesar(String mensaje) {

        if (mensaje == null || mensaje.trim().equals("")) {
            return construirErrorJson("Mensaje vacio");
        }

        if (mensaje.equalsIgnoreCase("BYE")) {
            return construirRespuestaSimpleJson(true, "Conexion cerrada");
        }

        String[] partes = mensaje.split("\\|");

        if (partes.length != 3) {
            return construirErrorJson("Formato invalido. Use BUSCAR|JSON|CEDULA o BUSCAR|XML|CEDULA");
        }

        String comando = partes[0].trim();
        String formatoTexto = partes[1].trim();
        String cedula = partes[2].trim();

        if (!comando.equalsIgnoreCase("BUSCAR")) {
            return construirErrorJson("Comando invalido");
        }

        FormatoSalida formato = obtenerFormato(formatoTexto);

        if (formato == null) {
            return construirErrorJson("Formato no soportado");
        }

        SolicitudPadron solicitud = new SolicitudPadron();
        solicitud.setCedula(cedula);
        solicitud.setFormato(formato);

        RespuestaPadron respuesta = servicio.buscar(solicitud);

        if (formato == FormatoSalida.JSON) {
            return Serializador.toJson(respuesta);
        } else {
            return Serializador.toXml(respuesta);
        }
    }

    private FormatoSalida obtenerFormato(String formatoTexto) {
        if (formatoTexto.equalsIgnoreCase("JSON")) {
            return FormatoSalida.JSON;
        }

        if (formatoTexto.equalsIgnoreCase("XML")) {
            return FormatoSalida.XML;
        }

        return null;
    }

    private String construirErrorJson(String mensaje) {
        RespuestaPadron respuesta = new RespuestaPadron();
        respuesta.setRecibido(false);
        respuesta.setRespuesta(mensaje);
        respuesta.setPersona(null);
        return Serializador.toJson(respuesta);
    }

    private String construirRespuestaSimpleJson(boolean recibido, String mensaje) {
        RespuestaPadron respuesta = new RespuestaPadron();
        respuesta.setRecibido(recibido);
        respuesta.setRespuesta(mensaje);
        respuesta.setPersona(null);
        return Serializador.toJson(respuesta);
    }
}