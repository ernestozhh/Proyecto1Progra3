/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logica;

import AccesoDatos.RepositorioPadron;
import DTO.RespuestaPadron;
import DTO.SolicitudPadron;
import Entidades.Persona;

public class ServicioPadron {

    private RepositorioPadron repositorioPadron;

    public ServicioPadron() {
        this.repositorioPadron = new RepositorioPadron();
    }

    public RespuestaPadron buscar(SolicitudPadron solicitud) {
        RespuestaPadron respuesta = new RespuestaPadron();

        if (solicitud == null) {
            respuesta.setRecibido(false);
            respuesta.setRespuesta("Solicitud nula");
            respuesta.setPersona(null);
            return respuesta;
        }

        if (solicitud.getCedula() == null || solicitud.getCedula().trim().equals("")) {
            respuesta.setRecibido(false);
            respuesta.setRespuesta("Cedula invalida");
            respuesta.setPersona(null);
            return respuesta;
        }

        Persona persona = repositorioPadron.buscarPorCedula(solicitud.getCedula().trim());

        if (persona == null) {
            respuesta.setRecibido(false);
            respuesta.setRespuesta("Persona no encontrada");
            respuesta.setPersona(null);
            return respuesta;
        }

        respuesta.setRecibido(true);
        respuesta.setRespuesta("Consulta exitosa");
        respuesta.setPersona(persona);

        return respuesta;
    }
}